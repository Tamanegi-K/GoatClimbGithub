
█░█ █▀▀ █▀█ █▀▄ ▄▀█ █▄░█ ▀█▀
▀▄▀ ██▄ █▀▄ █▄▀ █▀█ █░▀█ ░█░

█░█ █ █▄▀ █▀▀
█▀█ █ █░█ ██▄ ALPHA
= = = = = = = = = = = = = = = = = =

= = = CONTROLS = = =

WASD: Movement
LMB: Interact/Pick up plants
Esc/Tab/P: Inventory Screen (WIP)


= = = DEBUGS = = =

H: Move WAY faster


= = = GAMEPLAY = = =

Take in the sights and relax as you explore the lands for all kinds of plants and wonders!


= = = OBJECTIVES = = =

Walk around and expand your collection of flowers and fauna. Explore the fantasy landscape. If you look hard enough, you might find a cool secret area or two; hint: you can walk onto the vines!


= = = MECHANICS = = =
- Plant collection
- Chill tunes to hike and vibe to!


= = = Work In Progress (Urgent) = = = 
- Cave behind waterfall
- Spawning village
- Fast Travel
- Inventory Management


= = = Work In Progress (If there's time) = = = 
- Different villagers 
- Day-Night System
- Flower shop


= = = Cancelled Contents = = =
- NPC questlines
- Medicine crafting


= = = Notes = = =
- Camera glitches into the ground when the viewing angel is too large; we are fixing it 
- Air walls are not placed yet; please watch your steps
- The item pickup display may sometimes display the wrong text; we're looking into it


= = = THE TEAM = = =
XU Haiyang - 2103036
Tamarinn KOH - 2100777